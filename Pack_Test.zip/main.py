# -*- coding: utf-8 -*-

from src.img_base import transformImg as trimg

wanted_colors = [(0,0,0),(255, 255, 255),(255,0,0),(0,255,0),(0,0,255),(255,255,0),(255,0,255),(0,255,255)]

trimg('chat.jpg', 'tr1.chat.jpg', 'c', 'p', wanted_colors)
trimg('chat.jpg', 'tr2.chat.jpg', 'c', 'g')
trimg('chat.jpg', 'tr3.chat.jpg', 'c', 'n')
trimg('chat.jpg', 'tr4.chat.jpg', 'c', 'ci_r')
trimg('chat.jpg', 'tr5.chat.jpg', 'c', 'ci_g')
trimg('chat.jpg', 'tr6.chat.jpg', 'c', 'ci_b')
trimg('chat.jpg', 'tr7.chat.jpg', 'c', 'k_r')
trimg('chat.jpg', 'tr8.chat.jpg', 'c', 'k_g')
trimg('chat.jpg', 'tr9.chat.jpg', 'c', 'k_b')
trimg('chat.jpg', 'tr10.chat.jpg', 'c', 'm_rg')
trimg('chat.jpg', 'tr11.chat.jpg', 'c', 'm_rb')
trimg('chat.jpg', 'tr12.chat.jpg', 'c', 'm_gb')
trimg('chat.jpg', 'tr13.chat.jpg', 's', 'r_w', width=135)
trimg('chat.jpg', 'tr14.chat.jpg', 's', 'r_h', height=270)
trimg('chat.jpg', 'tr15.chat.jpg', 's', 'r_wh', width=202, height=156)
trimg('chat.jpg', 'tr16.chat.jpg', 's', 'r_s', scale=0.756)
trimg('chat.jpg', 'tr17.chat.jpg', 's', 's_h')
trimg('chat.jpg', 'tr18.chat.jpg', 's', 's_v')
trimg('chat.jpg', 'tr19.chat.jpg', 's', 't_t', value=25)
trimg('chat.jpg', 'tr20.chat.jpg', 's', 't_b', value=25)
trimg('chat.jpg', 'tr21.chat.jpg', 's', 't_l', value=25)
trimg('chat.jpg', 'tr22.chat.jpg', 's', 't_r', value=25)
